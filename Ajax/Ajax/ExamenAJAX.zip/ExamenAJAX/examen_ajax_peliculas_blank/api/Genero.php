<?php
class Genero { 

public string $nombre;

function __construct($nombre)
{
	$this->nombre = $nombre;
}
	
}

